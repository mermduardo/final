package com.usa.misiontic.demo1.repository.crudRepository;

public interface AdminCrudRepository {
}
