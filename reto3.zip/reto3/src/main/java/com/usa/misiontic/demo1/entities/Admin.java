package com.usa.misiontic.demo1.entities;

public class Admin {
}
