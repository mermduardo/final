package com.usa.misiontic.demo1.repository.crudRepository;

import com.usa.misiontic.demo1.entities.Reservation;
import org.springframework.data.repository.CrudRepository;

public interface ReservationCrudRepository extends CrudRepository<Reservation, Integer>{

}
