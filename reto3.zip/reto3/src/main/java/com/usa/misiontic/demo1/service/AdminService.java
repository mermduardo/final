package com.usa.misiontic.demo1.service;

public class AdminService {
}
