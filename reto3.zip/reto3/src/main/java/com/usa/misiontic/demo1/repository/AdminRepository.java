package com.usa.misiontic.demo1.repository;

public class AdminRepository {
}
