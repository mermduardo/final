package com.usa.misiontic.demo1.controller;

public class AdminController {

}
